package com.dbs.cabservices.cabservices;

public class Constants {

    public static final String GET_CABS="172.16.0.138:8080/api/taxi";
}
